package com.example.guessthenumber;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Locale;

import static android.widget.Toast.LENGTH_SHORT;

public class MainActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {

    int result;
    Button button;
    int count = 15;
    TextToSpeech textToSpeech;

    static int getRandomNumber(int max, int min) {
        return (int)((Math.random() * (max - min)) + min);
    }

    public void makeToast(String str) {
        Toast.makeText(MainActivity.this, str, LENGTH_SHORT).show();
        speakOut(str);
    }

    public void clickFunction(View view) {
        int userGuessing;
        EditText variable = findViewById(R.id.editId);
        userGuessing = Integer.parseInt(variable.getText().toString());
        if (count != 0) {
            if (userGuessing < result) {
                makeToast("Think of Higher Number, Try Again");
                count--;
            } else if (userGuessing > result) {
                makeToast("Think of Lower Number, Try Again");
                count--;
            } else {
                Intent intent =new Intent(MainActivity.this,MainActivity2.class);
                startActivity(intent);
                makeToast("wow" +
                        "!! You Got the Number");
            }
        } else {
            makeToast("Oops!! You lost the game!!");
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int min = 1;
        int max = 100;
        result = getRandomNumber(min, max);

        textToSpeech = new TextToSpeech(this, this);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = textToSpeech.setLanguage(Locale.getDefault());
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Toast.makeText(this, "Text to speech not supported on your device", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Text to speech initialization failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void speakOut(String text) {
        textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
    }
}
